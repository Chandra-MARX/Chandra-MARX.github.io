extern int user_open_source (char **, int, double,
			     double, double, double);

extern void user_close_source (void);

extern int user_create_ray (double *, double *,
			    double *, double *, double *);

/* Not required */
extern int user_start_iteration (void);
